// 315112672 Maayan Bahar

package com.company;

/**
 * The game.
 */
public class Ass3Game {
    /**
     * @param args The arguments. empty
     */
    public static void main(String[] args) {
//        GameLevel game = new GameLevel();
//        game.initialize(new LevelOne());
//        game.run();
    }
}
